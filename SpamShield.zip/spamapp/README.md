# SpamShield — AI Spam Email Detection (Desktop App)

A clean, modern, fully-offline desktop application built with Python + Tkinter
that uses a trained Naive Bayes machine-learning model to detect spam.

## Features

- 🔐 **Login & signup** with strict validation
  - Email must be a real email format
  - Password must be 6+ chars and contain a letter, a number and a symbol
- 👤 **User profile** (initials avatar in the top-right corner — click to view)
- 🌗 **Light & dark themes** (toggle anytime)
- 🤖 **AI spam detection** (Multinomial Naive Bayes + TF-IDF)
  - Result shown as **🚫 SPAM** in red or **✅ NOT SPAM** in green
  - Confidence percentage
  - Sound effect on each result (alert / success)
- 📧 **Optional Gmail connection** (with explicit permission dialog)
  - Polls your inbox every 30s using IMAP
  - Desktop notification + sound when a new email arrives
  - Brings the window to the front and pre-loads the message
  - One-click "Scan latest Gmail" button
- 🪶 Fully **offline & self-contained** — no external APIs

## Quick start

```bash
# 1. Install Python 3.9+ (with tkinter — included on Windows/macOS)
# 2. Install dependencies:
pip install scikit-learn pandas joblib pygame plyer pillow

# 3. (optional) retrain the model
python train_model.py

# 4. Run the app
python spam_app.py
```

The first run will create:
- `users.json` — local account store (passwords are SHA-256 hashed)
- `spam_model.joblib` — trained ML model (auto-trained if missing)

## Files

| File | Purpose |
|------|---------|
| `spam_app.py` | Main desktop application |
| `train_model.py` | Trains the spam classifier |
| `make_sounds.py` | Generates `alert.wav` + `success.wav` (already included) |
| `spam_model.joblib` | Pre-trained ML pipeline |
| `app_icon.png` / `app_icon.ico` | App icon |
| `alert.wav`, `success.wav` | Result sound effects |

## Gmail connection — how it works

This app uses Gmail's standard **IMAP** protocol with a Google **App Password**.
That keeps it 100% offline-friendly: no OAuth servers, no third-party APIs.

1. Go to <https://myaccount.google.com> → Security → 2-Step Verification → App passwords
2. Create a new app password for "Mail"
3. In SpamShield click **Connect Gmail**, accept the permission dialog,
   and paste your Gmail address + the 16-character app password.

Credentials live in memory only (never written to disk) and are sent only
to `imap.gmail.com`.

## About "notify on phone and redirect into the app"

Phone-to-desktop push notifications aren't possible from a fully offline,
self-contained desktop app (that requires a server + a companion mobile app).
The closest equivalent — and what SpamShield does — is:

- watch your Gmail inbox in the background,
- show a **system desktop notification** the moment a new email arrives,
- play the alert sound,
- raise the SpamShield window to the front and load the message ready to scan.

## Tech

Python · Tkinter · scikit-learn (Multinomial Naive Bayes + TF-IDF) ·
pygame (sounds) · plyer (notifications) · imaplib (Gmail).
