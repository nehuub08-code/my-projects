"""
train_model.py
---------------
Trains a Multinomial Naive Bayes spam classifier on the classic
SMS Spam Collection dataset and saves it to spam_model.joblib.

If the dataset file (spam.csv) is missing, a small built-in
fallback dataset is used so the app still works fully offline.
"""

import os
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(HERE, "spam_model.joblib")
CSV_PATH = os.path.join(HERE, "spam.csv")


# --- Built-in fallback dataset (small but balanced) ---
FALLBACK = [
    ("ham",  "Hey, are we still meeting for lunch tomorrow?"),
    ("ham",  "Don't forget to bring the documents to the office."),
    ("ham",  "Happy birthday! Wishing you a wonderful day."),
    ("ham",  "Can you send me the report by Friday please?"),
    ("ham",  "I'll call you back in 10 minutes."),
    ("ham",  "Mom asked if you're coming home for dinner."),
    ("ham",  "Meeting moved to 3pm, conference room B."),
    ("ham",  "Thanks for your help yesterday, really appreciate it."),
    ("ham",  "The project deadline is next Monday."),
    ("ham",  "Let's catch up over coffee this weekend."),
    ("ham",  "Your package has been delivered to your address."),
    ("ham",  "Reminder: dentist appointment at 9am."),
    ("ham",  "I love the photos you sent from the trip!"),
    ("ham",  "Please review the attached file when you get a chance."),
    ("ham",  "Good morning, hope you have a great day."),
    ("spam", "Congratulations! You won a $1000 Walmart gift card. Click here to claim."),
    ("spam", "URGENT! Your account has been suspended. Verify now at http://bit.ly/scam"),
    ("spam", "You have been selected for a free iPhone 15. Reply WIN to claim."),
    ("spam", "Free entry in 2 a weekly competition to win FA Cup tickets. Text WIN to 80086."),
    ("spam", "Get cheap loans approved instantly! No credit check required. Apply now."),
    ("spam", "Hot singles in your area want to meet you tonight! Click here."),
    ("spam", "Earn $5000 per week working from home. Limited spots available!"),
    ("spam", "Your PayPal account is locked. Login here to restore: http://paypa1-login.com"),
    ("spam", "WINNER!! You have won a 2-week holiday in Bahamas. Call 09061234567."),
    ("spam", "Claim your free Bitcoin now! Investment opportunity of a lifetime."),
    ("spam", "Final notice: pay your overdue invoice or face legal action. Click link."),
    ("spam", "Lose 20kg in 2 weeks with this miracle pill! Buy now 70% off."),
    ("spam", "Your card was charged $499. If not you, click here to dispute immediately."),
    ("spam", "Cheap meds online! Viagra, Cialis, no prescription needed."),
    ("spam", "Re: Your loan application has been pre-approved for $50,000!"),
]


def load_data():
    """Load the spam dataset, falling back to the built-in samples."""
    if os.path.exists(CSV_PATH):
        # Standard SMS Spam Collection format: label,message
        df = pd.read_csv(CSV_PATH, encoding="latin-1")
        # Normalise columns (the kaggle file has v1,v2)
        if "v1" in df.columns and "v2" in df.columns:
            df = df.rename(columns={"v1": "label", "v2": "text"})
        df = df[["label", "text"]].dropna()
    else:
        df = pd.DataFrame(FALLBACK, columns=["label", "text"])
    df["label"] = df["label"].str.lower().map({"ham": 0, "spam": 1})
    return df


def train():
    df = load_data()
    X, y = df["text"].astype(str), df["label"].astype(int)

    # Split only if we have enough rows for it to be meaningful.
    if len(df) > 50:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
    else:
        X_train, X_test, y_train, y_test = X, X, y, y

    # Pipeline = TF-IDF features  →  Multinomial Naive Bayes
    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            min_df=1,
            max_df=0.95,
        )),
        ("clf", MultinomialNB(alpha=0.3)),
    ])

    pipe.fit(X_train, y_train)
    acc = pipe.score(X_test, y_test)
    print(f"Training samples: {len(X_train)} | Test accuracy: {acc:.3f}")

    joblib.dump(pipe, MODEL_PATH)
    print(f"Saved model to {MODEL_PATH}")


if __name__ == "__main__":
    train()
