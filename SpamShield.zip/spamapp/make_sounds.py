"""Generate two short WAV sound effects (alert + success) using only stdlib."""
import wave, math, struct, os

HERE = os.path.dirname(os.path.abspath(__file__))
SR = 44100  # sample rate

def write_wav(path, samples):
    with wave.open(path, "w") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        frames = b"".join(struct.pack("<h", max(-32767, min(32767, int(s * 32767)))) for s in samples)
        w.writeframes(frames)

def tone(freq, dur, vol=0.5, fade=0.02):
    n = int(SR * dur)
    out = []
    fade_n = int(SR * fade)
    for i in range(n):
        env = 1.0
        if i < fade_n: env = i / fade_n
        elif i > n - fade_n: env = (n - i) / fade_n
        out.append(vol * env * math.sin(2 * math.pi * freq * i / SR))
    return out

# ALERT (spam): two harsh low buzzes
alert = tone(420, 0.18, 0.55) + tone(0, 0.05, 0) + tone(320, 0.22, 0.6)
write_wav(os.path.join(HERE, "alert.wav"), alert)

# SUCCESS (not spam): pleasant rising chime C5 -> E5 -> G5
success = tone(523.25, 0.12, 0.4) + tone(659.25, 0.12, 0.4) + tone(783.99, 0.22, 0.45)
write_wav(os.path.join(HERE, "success.wav"), success)

print("Wrote alert.wav and success.wav")
