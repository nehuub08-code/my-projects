"""
SpamShield - Desktop Spam Email Detection App
=============================================

Features
--------
* Login & signup with strict email + password validation (local, offline)
* User profile (avatar initials in the top-right corner)
* Modern Tkinter UI with light & dark themes
* "Check Spam" using a trained Naive Bayes ML model
* Result shown in red (Spam) or green (Not Spam) + sound effect
* Optional Gmail inbox connection (IMAP) with explicit permission dialog
  - polls inbox in the background
  - desktop notification + sound on new mail
  - one-click scan of the latest message
* Fully offline & self-contained (no external APIs)

Run:  python spam_app.py
"""

import os
import re
import json
import hashlib
import threading
import time
import imaplib
import email
from email.header import decode_header
from datetime import datetime
from tkinter import Tk, Toplevel, StringVar, BooleanVar, END
from tkinter import ttk, messagebox, scrolledtext

import joblib

# Sound (pygame) - optional, app still runs without audio
try:
    import pygame
    pygame.mixer.init()
    SOUND_OK = True
except Exception:
    SOUND_OK = False

# Desktop notifications - optional
try:
    from plyer import notification
    NOTIFY_OK = True
except Exception:
    NOTIFY_OK = False


# ---------------------------------------------------------------- paths
HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(HERE, "spam_model.joblib")
USERS_PATH = os.path.join(HERE, "users.json")
ICON_PATH = os.path.join(HERE, "app_icon.png")
ALERT_WAV = os.path.join(HERE, "alert.wav")
SUCCESS_WAV = os.path.join(HERE, "success.wav")


# ---------------------------------------------------------------- theme
THEMES = {
    "light": {
        "bg": "#F4F6FB", "panel": "#FFFFFF", "fg": "#1B2330",
        "muted": "#6B7280", "primary": "#4F46E5", "primary_fg": "#FFFFFF",
        "accent": "#0EA5E9", "border": "#E5E7EB",
        "spam": "#DC2626", "ham": "#16A34A", "entry": "#FFFFFF",
    },
    "dark": {
        "bg": "#0F172A", "panel": "#1E293B", "fg": "#E2E8F0",
        "muted": "#94A3B8", "primary": "#6366F1", "primary_fg": "#FFFFFF",
        "accent": "#22D3EE", "border": "#334155",
        "spam": "#F87171", "ham": "#4ADE80", "entry": "#0B1220",
    },
}


# ---------------------------------------------------------------- helpers
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
# Password: >=6 chars, has letter, digit, special
PASSWORD_RE = re.compile(
    r"^(?=.*[A-Za-z])(?=.*\d)(?=.*[!@#$%^&*()_\-+=\[\]{};':\",.<>/?\\|`~]).{6,}$"
)


def hash_password(pw: str) -> str:
    return hashlib.sha256(pw.encode("utf-8")).hexdigest()


def load_users() -> dict:
    if not os.path.exists(USERS_PATH):
        return {}
    try:
        with open(USERS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_users(users: dict) -> None:
    with open(USERS_PATH, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=2)


def play_sound(path: str) -> None:
    if not SOUND_OK or not os.path.exists(path):
        return
    try:
        snd = pygame.mixer.Sound(path)
        snd.play()
    except Exception:
        pass


def notify(title: str, msg: str) -> None:
    if not NOTIFY_OK:
        return
    try:
        notification.notify(title=title, message=msg, app_name="SpamShield", timeout=5)
    except Exception:
        pass


# ---------------------------------------------------------------- model
class SpamModel:
    """Lightweight wrapper around the trained sklearn pipeline."""

    def __init__(self, path: str):
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"Model file not found: {path}\nRun `python train_model.py` first."
            )
        self.pipe = joblib.load(path)

    def predict(self, text: str):
        """Returns (label, confidence_pct)."""
        text = (text or "").strip()
        if not text:
            return "ham", 0.0
        proba = self.pipe.predict_proba([text])[0]
        spam_p = float(proba[1])
        label = "spam" if spam_p >= 0.5 else "ham"
        conf = spam_p if label == "spam" else (1 - spam_p)
        return label, conf * 100


# ---------------------------------------------------------------- Login
class LoginWindow:
    def __init__(self, root: Tk, on_success):
        self.root = root
        self.on_success = on_success
        self.theme_name = "light"

        root.title("SpamShield - Sign In")
        root.geometry("440x560")
        root.minsize(420, 540)
        try:
            root.iconphoto(True, _load_icon())
        except Exception:
            pass

        self.container = ttk.Frame(root)
        self.container.pack(fill="both", expand=True)
        self._build()
        self._apply_theme()

    def _build(self):
        c = self.container
        for w in c.winfo_children():
            w.destroy()

        self.header = ttk.Frame(c)
        self.header.pack(fill="x", pady=(28, 8))
        self.title_lbl = ttk.Label(self.header, text="🛡  SpamShield",
                                   font=("Segoe UI", 22, "bold"), anchor="center")
        self.title_lbl.pack()
        self.sub_lbl = ttk.Label(self.header, text="AI-powered spam detection",
                                 font=("Segoe UI", 10))
        self.sub_lbl.pack(pady=(2, 0))

        self.card = ttk.Frame(c, padding=22, style="Card.TFrame")
        self.card.pack(padx=28, pady=18, fill="both", expand=True)

        self.mode = StringVar(value="login")  # login | signup

        self.tabs = ttk.Frame(self.card)
        self.tabs.pack(fill="x", pady=(0, 14))
        self.btn_login = ttk.Button(self.tabs, text="Sign In",
                                    command=lambda: self._switch("login"))
        self.btn_signup = ttk.Button(self.tabs, text="Create Account",
                                     command=lambda: self._switch("signup"))
        self.btn_login.pack(side="left", expand=True, fill="x", padx=(0, 4))
        self.btn_signup.pack(side="left", expand=True, fill="x", padx=(4, 0))

        self.form = ttk.Frame(self.card)
        self.form.pack(fill="both", expand=True)

        self.username_var = StringVar()
        self.email_var = StringVar()
        self.password_var = StringVar()

        self.username_row = self._field(self.form, "Username", self.username_var)
        self._field(self.form, "Email", self.email_var)
        self._field(self.form, "Password", self.password_var, show="•")

        self.hint = ttk.Label(self.form,
            text="Password: 6+ chars, must include a letter, a number and a symbol.",
            font=("Segoe UI", 8), wraplength=320, justify="left")
        self.hint.pack(anchor="w", pady=(2, 10))

        self.submit = ttk.Button(self.form, text="Sign In",
                                 style="Primary.TButton", command=self._submit)
        self.submit.pack(fill="x", pady=(6, 6), ipady=4)

        self.theme_btn = ttk.Button(c, text="🌙 Dark mode",
                                    command=self._toggle_theme)
        self.theme_btn.pack(pady=(0, 14))

        self._switch("login")

    def _field(self, parent, label, var, show=None):
        wrap = ttk.Frame(parent)
        wrap.pack(fill="x", pady=4)
        ttk.Label(wrap, text=label, font=("Segoe UI", 9, "bold")).pack(anchor="w")
        ent = ttk.Entry(wrap, textvariable=var, show=show or "")
        ent.pack(fill="x", ipady=5)
        return wrap

    def _switch(self, mode):
        self.mode.set(mode)
        if mode == "signup":
            self.username_row.pack(fill="x", pady=4, before=self.form.winfo_children()[1])
            self.submit.config(text="Create Account")
        else:
            self.username_row.pack_forget()
            self.submit.config(text="Sign In")

    def _submit(self):
        email_v = self.email_var.get().strip()
        pw_v = self.password_var.get()
        users = load_users()

        if not EMAIL_RE.match(email_v):
            messagebox.showerror("Invalid email",
                                 "Please enter a valid email address.")
            return
        if not PASSWORD_RE.match(pw_v):
            messagebox.showerror("Weak password",
                "Password must be at least 6 characters and include a "
                "letter, a number and a special character.")
            return

        if self.mode.get() == "signup":
            uname = self.username_var.get().strip()
            if len(uname) < 2:
                messagebox.showerror("Invalid username",
                                     "Username must be at least 2 characters.")
                return
            if email_v in users:
                messagebox.showerror("Account exists",
                                     "An account with this email already exists.")
                return
            users[email_v] = {"username": uname, "password": hash_password(pw_v)}
            save_users(users)
            messagebox.showinfo("Welcome!", f"Account created for {uname}.")
            self.on_success({"email": email_v, "username": uname},
                            self.theme_name)
        else:
            user = users.get(email_v)
            if not user or user["password"] != hash_password(pw_v):
                messagebox.showerror("Login failed",
                                     "Invalid email or password.")
                return
            self.on_success({"email": email_v, "username": user["username"]},
                            self.theme_name)

    def _toggle_theme(self):
        self.theme_name = "dark" if self.theme_name == "light" else "light"
        self.theme_btn.config(
            text="☀ Light mode" if self.theme_name == "dark" else "🌙 Dark mode")
        self._apply_theme()

    def _apply_theme(self):
        apply_theme(self.root, self.theme_name)


# ---------------------------------------------------------------- Main App
class MainApp:
    def __init__(self, root: Tk, user: dict, theme_name: str, model: SpamModel):
        self.root = root
        self.user = user
        self.theme_name = theme_name
        self.model = model
        self.gmail_thread = None
        self.gmail_stop = threading.Event()
        self.gmail_creds = None  # {"email":..., "app_password":...}
        self.last_uid = None

        root.title(f"SpamShield - {user['username']}")
        root.geometry("900x640")
        root.minsize(820, 600)
        try:
            root.iconphoto(True, _load_icon())
        except Exception:
            pass

        self._build()
        self._apply_theme()

    # ---- UI
    def _build(self):
        for w in self.root.winfo_children():
            w.destroy()

        # Top bar
        self.topbar = ttk.Frame(self.root, style="Top.TFrame")
        self.topbar.pack(fill="x")
        ttk.Label(self.topbar, text="🛡  SpamShield",
                  font=("Segoe UI", 14, "bold")).pack(side="left", padx=16, pady=12)

        right = ttk.Frame(self.topbar)
        right.pack(side="right", padx=10, pady=8)

        self.theme_btn = ttk.Button(
            right, text="🌙" if self.theme_name == "light" else "☀",
            width=3, command=self._toggle_theme)
        self.theme_btn.pack(side="right", padx=4)

        self.gmail_btn = ttk.Button(
            right, text="📧 Connect Gmail", command=self._connect_gmail)
        self.gmail_btn.pack(side="right", padx=4)

        # Profile avatar (initials)
        initials = "".join([p[0] for p in self.user["username"].split()][:2]).upper()
        self.avatar = ttk.Label(
            right, text=initials, width=3, anchor="center",
            font=("Segoe UI", 11, "bold"), style="Avatar.TLabel")
        self.avatar.pack(side="right", padx=8, ipady=4)
        self.avatar.bind("<Button-1>", lambda e: self._show_profile())

        # Body
        body = ttk.Frame(self.root, padding=20)
        body.pack(fill="both", expand=True)

        ttk.Label(body, text="Paste an email or message below",
                  font=("Segoe UI", 12, "bold")).pack(anchor="w")
        ttk.Label(body, text="Our AI model will tell you if it looks like spam.",
                  style="Muted.TLabel").pack(anchor="w", pady=(0, 10))

        self.text = scrolledtext.ScrolledText(
            body, height=14, wrap="word", font=("Segoe UI", 10),
            relief="flat", borderwidth=1)
        self.text.pack(fill="both", expand=True)

        actions = ttk.Frame(body)
        actions.pack(fill="x", pady=12)

        ttk.Button(actions, text="🔍  Check Spam", style="Primary.TButton",
                   command=self._check).pack(side="left", ipadx=10, ipady=6)
        ttk.Button(actions, text="Clear", command=self._clear).pack(
            side="left", padx=8, ipady=6)
        ttk.Button(actions, text="📥  Scan latest Gmail",
                   command=self._scan_latest).pack(side="left", padx=8, ipady=6)

        # Result panel
        self.result_frame = ttk.Frame(body, style="Result.TFrame", padding=18)
        self.result_frame.pack(fill="x", pady=(8, 0))
        self.result_lbl = ttk.Label(self.result_frame, text="Awaiting input…",
                                    font=("Segoe UI", 18, "bold"))
        self.result_lbl.pack(anchor="w")
        self.result_sub = ttk.Label(self.result_frame, text="",
                                    style="Muted.TLabel")
        self.result_sub.pack(anchor="w", pady=(4, 0))

        # Status bar
        self.status = ttk.Label(self.root, text="Ready.", anchor="w",
                                style="Status.TLabel", padding=(12, 4))
        self.status.pack(fill="x", side="bottom")

    # ---- Actions
    def _check(self):
        msg = self.text.get("1.0", END).strip()
        if not msg:
            messagebox.showwarning("Empty", "Please paste a message first.")
            return
        try:
            label, conf = self.model.predict(msg)
        except Exception as e:
            messagebox.showerror("Error", f"Prediction failed:\n{e}")
            return

        theme = THEMES[self.theme_name]
        if label == "spam":
            self.result_lbl.config(text="🚫  SPAM DETECTED", foreground=theme["spam"])
            self.result_sub.config(text=f"Confidence: {conf:.1f}%  •  Be careful with links and attachments.")
            play_sound(ALERT_WAV)
        else:
            self.result_lbl.config(text="✅  NOT SPAM", foreground=theme["ham"])
            self.result_sub.config(text=f"Confidence: {conf:.1f}%  •  This message looks safe.")
            play_sound(SUCCESS_WAV)
        self.status.config(text=f"Checked at {datetime.now().strftime('%H:%M:%S')}")

    def _clear(self):
        self.text.delete("1.0", END)
        self.result_lbl.config(text="Awaiting input…",
                               foreground=THEMES[self.theme_name]["fg"])
        self.result_sub.config(text="")

    def _show_profile(self):
        u = self.user
        messagebox.showinfo("Profile",
            f"Username: {u['username']}\nEmail: {u['email']}\n\n"
            f"Theme: {self.theme_name.title()}\n"
            f"Gmail connected: {'Yes' if self.gmail_creds else 'No'}")

    # ---- Theme
    def _toggle_theme(self):
        self.theme_name = "dark" if self.theme_name == "light" else "light"
        self.theme_btn.config(text="🌙" if self.theme_name == "light" else "☀")
        self._apply_theme()

    def _apply_theme(self):
        apply_theme(self.root, self.theme_name)
        # Re-style the ScrolledText (not a ttk widget)
        t = THEMES[self.theme_name]
        self.text.config(bg=t["entry"], fg=t["fg"], insertbackground=t["fg"],
                         highlightbackground=t["border"], highlightthickness=1)

    # ---- Gmail
    def _connect_gmail(self):
        if self.gmail_creds:
            if messagebox.askyesno("Disconnect Gmail",
                                   "Disconnect your Gmail account?"):
                self.gmail_stop.set()
                self.gmail_creds = None
                self.gmail_btn.config(text="📧 Connect Gmail")
                self.status.config(text="Gmail disconnected.")
            return

        # Permission dialog
        ok = messagebox.askyesno(
            "Permission required",
            "SpamShield would like to connect to your Gmail inbox to:\n\n"
            "  • check for new incoming messages\n"
            "  • notify you immediately when one arrives\n"
            "  • let you scan it for spam in one click\n\n"
            "Your credentials are kept only in memory on this computer\n"
            "and are never sent anywhere except to imap.gmail.com.\n\n"
            "Do you grant permission?")
        if not ok:
            return

        GmailDialog(self.root, self.theme_name, self._gmail_set)

    def _gmail_set(self, email_addr: str, app_pw: str):
        # Validate by attempting login once
        try:
            m = imaplib.IMAP4_SSL("imap.gmail.com")
            m.login(email_addr, app_pw)
            m.select("INBOX")
            m.logout()
        except Exception as e:
            messagebox.showerror("Gmail login failed",
                f"Could not connect:\n{e}\n\n"
                "Tip: use a Google App Password, not your normal password.")
            return

        self.gmail_creds = {"email": email_addr, "app_password": app_pw}
        self.gmail_btn.config(text="📧 Gmail ✓")
        self.status.config(text=f"Connected to {email_addr}. Watching inbox…")
        self.gmail_stop.clear()
        self.gmail_thread = threading.Thread(target=self._gmail_loop, daemon=True)
        self.gmail_thread.start()

    def _gmail_loop(self):
        """Background poller: every 30s look for new messages."""
        while not self.gmail_stop.is_set():
            try:
                m = imaplib.IMAP4_SSL("imap.gmail.com")
                m.login(self.gmail_creds["email"],
                        self.gmail_creds["app_password"])
                m.select("INBOX")
                typ, data = m.uid("search", None, "ALL")
                uids = data[0].split()
                if uids:
                    newest = uids[-1]
                    if self.last_uid is None:
                        self.last_uid = newest
                    elif newest != self.last_uid:
                        self.last_uid = newest
                        subj, body = _fetch_message(m, newest)
                        self._on_new_mail(subj, body)
                m.logout()
            except Exception as e:
                self.root.after(0, lambda: self.status.config(
                    text=f"Gmail error: {e}"))
            # sleep with cancel support
            for _ in range(30):
                if self.gmail_stop.is_set():
                    return
                time.sleep(1)

    def _on_new_mail(self, subject: str, body: str):
        notify("New email received", subject or "(no subject)")
        play_sound(SUCCESS_WAV)

        def show():
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
            self.text.delete("1.0", END)
            self.text.insert(END, f"Subject: {subject}\n\n{body}")
            self.status.config(text="New email loaded — click Check Spam.")
        self.root.after(0, show)

    def _scan_latest(self):
        if not self.gmail_creds:
            messagebox.showinfo("Gmail not connected",
                                "Connect your Gmail account first.")
            return
        try:
            m = imaplib.IMAP4_SSL("imap.gmail.com")
            m.login(self.gmail_creds["email"], self.gmail_creds["app_password"])
            m.select("INBOX")
            typ, data = m.uid("search", None, "ALL")
            uids = data[0].split()
            if not uids:
                messagebox.showinfo("Empty", "No messages found.")
                return
            subj, body = _fetch_message(m, uids[-1])
            m.logout()
            self.text.delete("1.0", END)
            self.text.insert(END, f"Subject: {subj}\n\n{body}")
            self._check()
        except Exception as e:
            messagebox.showerror("Error", str(e))


# ---------------------------------------------------------------- Gmail dialog
class GmailDialog(Toplevel):
    def __init__(self, parent, theme_name, on_ok):
        super().__init__(parent)
        self.title("Connect Gmail")
        self.geometry("420x280")
        self.resizable(False, False)
        self.on_ok = on_ok

        ttk.Label(self, text="Gmail address",
                  font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=20, pady=(20, 2))
        self.email_v = StringVar()
        ttk.Entry(self, textvariable=self.email_v).pack(
            fill="x", padx=20, ipady=4)

        ttk.Label(self, text="App password (16 chars, from Google account)",
                  font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=20, pady=(12, 2))
        self.pw_v = StringVar()
        ttk.Entry(self, textvariable=self.pw_v, show="•").pack(
            fill="x", padx=20, ipady=4)

        ttk.Label(self,
            text="Generate one at: myaccount.google.com → Security → App passwords",
            wraplength=380, font=("Segoe UI", 8)).pack(padx=20, pady=(8, 0), anchor="w")

        btns = ttk.Frame(self)
        btns.pack(fill="x", padx=20, pady=18)
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Connect", style="Primary.TButton",
                   command=self._ok).pack(side="right", padx=4)

        apply_theme(self, theme_name)

    def _ok(self):
        e = self.email_v.get().strip()
        p = self.pw_v.get().strip()
        if not EMAIL_RE.match(e):
            messagebox.showerror("Invalid", "Enter a valid Gmail address.")
            return
        if len(p) < 8:
            messagebox.showerror("Invalid", "Enter your Google app password.")
            return
        self.destroy()
        self.on_ok(e, p)


# ---------------------------------------------------------------- utilities
def _fetch_message(m: imaplib.IMAP4_SSL, uid: bytes):
    typ, data = m.uid("fetch", uid, "(RFC822)")
    raw = data[0][1]
    msg = email.message_from_bytes(raw)
    subj_raw = msg.get("Subject", "")
    subj_parts = decode_header(subj_raw)
    subject = "".join(
        (p.decode(enc or "utf-8", errors="replace") if isinstance(p, bytes) else p)
        for p, enc in subj_parts)
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                body = part.get_payload(decode=True).decode(errors="replace")
                break
    else:
        body = msg.get_payload(decode=True).decode(errors="replace") if msg.get_payload(decode=True) else ""
    return subject, body[:5000]


_ICON_CACHE = {}
def _load_icon():
    from tkinter import PhotoImage
    if "img" not in _ICON_CACHE and os.path.exists(ICON_PATH):
        _ICON_CACHE["img"] = PhotoImage(file=ICON_PATH)
    return _ICON_CACHE.get("img")


def apply_theme(root, theme_name: str):
    t = THEMES[theme_name]
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass

    root.configure(bg=t["bg"])
    style.configure(".", background=t["bg"], foreground=t["fg"],
                    font=("Segoe UI", 10))
    style.configure("TFrame", background=t["bg"])
    style.configure("TLabel", background=t["bg"], foreground=t["fg"])
    style.configure("Muted.TLabel", background=t["bg"], foreground=t["muted"])
    style.configure("Status.TLabel", background=t["panel"], foreground=t["muted"])

    style.configure("Card.TFrame", background=t["panel"], relief="flat")
    style.configure("Top.TFrame", background=t["panel"])
    style.configure("Result.TFrame", background=t["panel"], relief="flat")

    style.configure("TButton", background=t["panel"], foreground=t["fg"],
                    borderwidth=1, focusthickness=0, padding=8)
    style.map("TButton",
              background=[("active", t["border"])],
              foreground=[("active", t["fg"])])

    style.configure("Primary.TButton", background=t["primary"],
                    foreground=t["primary_fg"], borderwidth=0, padding=10,
                    font=("Segoe UI", 10, "bold"))
    style.map("Primary.TButton",
              background=[("active", t["accent"])])

    style.configure("Avatar.TLabel", background=t["primary"],
                    foreground=t["primary_fg"])

    style.configure("TEntry", fieldbackground=t["entry"], foreground=t["fg"],
                    bordercolor=t["border"], insertcolor=t["fg"], padding=5)


# ---------------------------------------------------------------- main
def main():
    if not os.path.exists(MODEL_PATH):
        # Auto-train if model missing
        from train_model import train
        train()

    model = SpamModel(MODEL_PATH)
    root = Tk()

    def on_login(user, theme_name):
        MainApp(root, user, theme_name, model)

    LoginWindow(root, on_login)
    root.mainloop()


if __name__ == "__main__":
    main()
